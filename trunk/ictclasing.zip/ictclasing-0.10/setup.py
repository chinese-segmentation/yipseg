from distutils.core import setup

setup(
      name="ictclasing",
      version="0.10",
      description="My test module",
      author="Robin Hood",
      url="http://www.csdn.net",
      py_modules = ['ictclasing']
      )